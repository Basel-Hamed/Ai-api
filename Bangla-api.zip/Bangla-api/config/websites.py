# config/websites.py
# ===============================================
# 📌 গুরুত্বপূর্ণ: শুধুমাত্র এখানেই সাইট যোগ করুন
# API শুধু এই লিস্টের সাইট থেকেই ডাটা আনতে পারবে
# ===============================================

# ---------- আপনার পছন্দের ওয়েবসাইট লিস্ট ----------
ALLOWED_WEBSITES = {
    # বাংলা নিউজ সাইট
    "prothomalo_eng": {
        "url": "https://en.prothomalo.com",
        "name": "Prothom Alo English",
        "category": "news",
        "language": "en",
        "active": True
    },
    
    "dailystar": {
        "url": "https://www.thedailystar.net",
        "name": "The Daily Star",
        "category": "news",
        "language": "en",
        "active": True
    },
    
    # আন্তর্জাতিক নিউজ
    "bbc": {
        "url": "https://www.bbc.com/news",
        "name": "BBC News",
        "category": "international",
        "language": "en",
        "active": True
    },
    
    "cnn": {
        "url": "https://www.cnn.com/world",
        "name": "CNN",
        "category": "international",
        "language": "en",
        "active": True
    },
    
    # টেকনোলজি সাইট
    "techcrunch": {
        "url": "https://techcrunch.com",
        "name": "TechCrunch",
        "category": "technology",
        "language": "en",
        "active": True
    },
    
    "theverge": {
        "url": "https://www.theverge.com",
        "name": "The Verge",
        "category": "technology",
        "language": "en",
        "active": True
    },
    
    # স্পোর্টস
    "espn": {
        "url": "https://www.espn.com",
        "name": "ESPN",
        "category": "sports",
        "language": "en",
        "active": True
    },
    
    # ============================================
    # ⭐ আপনার নতুন সাইট এখানে যোগ করুন:
    # 
    # "site_name": {
    #     "url": "https://your-site.com",
    #     "name": "Your Site Name",
    #     "category": "news/tech/sports",
    #     "language": "en",
    #     "active": True
    # },
    # ============================================
}

# ---------- হেল্পার ফাংশন ----------
def get_allowed_websites():
    """অনুমোদিত ওয়েবসাইটের তালিকা রিটার্ন করে"""
    return {name: info for name, info in ALLOWED_WEBSITES.items() if info.get("active", True)}

def is_website_allowed(name):
    """চেক করে যে সাইটটি অনুমোদিত কিনা"""
    return name in ALLOWED_WEBSITES and ALLOWED_WEBSITES[name].get("active", True)

def get_website_info(name):
    """সাইটের তথ্য রিটার্ন করে"""
    return ALLOWED_WEBSITES.get(name, {})

def get_websites_by_category(category):
    """ক্যাটাগরি অনুযায়ী সাইট ফিল্টার করে"""
    return {
        name: info for name, info in ALLOWED_WEBSITES.items() 
        if info.get("category") == category and info.get("active", True)
    }
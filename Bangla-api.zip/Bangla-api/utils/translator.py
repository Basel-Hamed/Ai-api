# utils/translator.py
from googletrans import Translator
import time

class BanglaTranslator:
    """টেক্সট বাংলায় অনুবাদ করার জন্য ক্লাস"""
    
    def __init__(self):
        self.translator = Translator()
        self.retry_count = 3
    
    def translate(self, text: str, dest: str = 'bn') -> str:
        """টেক্সট অনুবাদ করে"""
        if not text:
            return ""
        
        for attempt in range(self.retry_count):
            try:
                result = self.translator.translate(text, dest=dest)
                return result.text
            except Exception as e:
                if attempt < self.retry_count - 1:
                    time.sleep(1)  # এক সেকেন্ড অপেক্ষা করে আবার চেষ্টা
                    continue
                else:
                    return f"[অনুবাদ ব্যর্থ: {text}]"
    
    def translate_batch(self, texts: list, dest: str = 'bn') -> list:
        """একাধিক টেক্সট একসাথে অনুবাদ করে"""
        results = []
        for text in texts:
            results.append(self.translate(text, dest))
            time.sleep(0.5)  # রেট লিমিট এড়াতে
        return results

# ট্রান্সলেটরের ইনস্ট্যান্স
translator = BanglaTranslator()

def translate_text(text: str, dest: str = 'bn') -> str:
    """টেক্সট অনুবাদ করার জন্য হেল্পার ফাংশন"""
    return translator.translate(text, dest)

def translate_batch(texts: list, dest: str = 'bn') -> list:
    """একাধিক টেক্সট অনুবাদ করার জন্য হেল্পার ফাংশন"""
    return translator.translate_batch(texts, dest)
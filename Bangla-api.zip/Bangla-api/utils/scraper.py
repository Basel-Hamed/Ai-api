# utils/scraper.py
import requests
from bs4 import BeautifulSoup
import time
from typing import List, Dict, Any

class WebScraper:
    """ওয়েব স্ক্র্যাপার ক্লাস - শুধু অনুমোদিত সাইট থেকে ডাটা আনে"""
    
    def __init__(self):
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        self.timeout = 10
    
    def fetch_headlines(self, url: str, limit: int = 5) -> List[str]:
        """ওয়েবসাইট থেকে হেডলাইন সংগ্রহ করে"""
        try:
            response = requests.get(url, headers=self.headers, timeout=self.timeout)
            soup = BeautifulSoup(response.text, 'html.parser')
            
            headlines = []
            # h1, h2, h3 ট্যাগ থেকে হেডলাইন খোঁজে
            for tag in ['h1', 'h2', 'h3']:
                for elem in soup.find_all(tag)[:limit]:
                    text = elem.get_text().strip()
                    if text and len(text) > 10 and text not in headlines:
                        headlines.append(text)
            
            # ডুপ্লিকেট বাদ দিয়ে limit পর্যন্ত নেয়
            unique_headlines = []
            for h in headlines:
                if h not in unique_headlines:
                    unique_headlines.append(h)
            
            return unique_headlines[:limit]
            
        except Exception as e:
            print(f"Scraping error: {e}")
            return []
    
    def fetch_articles(self, url: str, limit: int = 3) -> List[Dict]:
        """আর্টিকেল সংগ্রহ করে (শিরোনাম + লিংক)"""
        try:
            response = requests.get(url, headers=self.headers, timeout=self.timeout)
            soup = BeautifulSoup(response.text, 'html.parser')
            
            articles = []
            # আর্টিকেল খোঁজে
            for article in soup.find_all(['article', '.post', '.card'])[:limit]:
                title_elem = article.find(['h1', 'h2', 'h3'])
                link_elem = article.find('a')
                
                if title_elem and link_elem:
                    title = title_elem.get_text().strip()
                    link = link_elem.get('href', '')
                    
                    # আপেক্ষিক লিংককে সম্পূর্ণ লিংকে রূপান্তর
                    if link and not link.startswith('http'):
                        from urllib.parse import urljoin
                        link = urljoin(url, link)
                    
                    articles.append({
                        'title': title,
                        'url': link
                    })
            
            return articles[:limit]
            
        except Exception as e:
            print(f"Article scraping error: {e}")
            return []
    
    def search_website(self, url: str, keyword: str) -> List[str]:
        """ওয়েবসাইটে কীওয়ার্ড সার্চ করে"""
        try:
            response = requests.get(url, headers=self.headers, timeout=self.timeout)
            soup = BeautifulSoup(response.text, 'html.parser')
            
            results = []
            # সব টেক্সট এলিমেন্টে সার্চ
            for elem in soup.find_all(['h1', 'h2', 'h3', 'p']):
                text = elem.get_text().strip()
                if keyword.lower() in text.lower() and len(text) < 200:
                    results.append(text[:150] + "...")
                    if len(results) >= 3:
                        break
            
            return results
            
        except Exception as e:
            return []

# স্ক্র্যাপারের ইনস্ট্যান্স
scraper = WebScraper()

def fetch_headlines(url: str, limit: int = 5) -> List[str]:
    """হেডলাইন ফেচ করার জন্য হেল্পার ফাংশন"""
    return scraper.fetch_headlines(url, limit)

def fetch_articles(url: str, limit: int = 3) -> List[Dict]:
    """আর্টিকেল ফেচ করার জন্য হেল্পার ফাংশন"""
    return scraper.fetch_articles(url, limit)

def search_website(url: str, keyword: str) -> List[str]:
    """সার্চ করার জন্য হেল্পার ফাংশন"""
    return scraper.search_website(url, keyword)